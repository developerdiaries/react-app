import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router'

class App extends React.Component{
   render(){
      return(
      		<div>
	      		<nav className="navbar navbar-default">
		            <div className="navbar-header">
		              <h1>Simple SPA</h1>
		              <ul className="nav nav-tabs">
		                <li role="presentation" className="active"><Link to="/">Home</Link></li>
		                <li role="presentation" className="active"><Link to="/stuff">Stuff</Link></li>
		                <li role="presentation" className="active"><Link to="/contact">Contact</Link></li>
		              </ul>
		            </div>
	            </nav>
	            <div className="content \">
	       			{this.props.children}
	            </div>
            </div>
         )   
   }
}

class Home extends React.Component{
  render() {
      return (
        <div className="navbar navbar-text">
          <h2>HELLO</h2>
          <p>Cras facilisis urna ornare ex volutpat, et
          convallis erat elementum. Ut aliquam, ipsum vitae
          gravida suscipit, metus dui bibendum est, eget rhoncus nibh
          metus nec massa. Maecenas hendrerit laoreet augue
          nec molestie. Cum sociis natoque penatibus et magnis
          dis parturient montes, nascetur ridiculus mus.</p>
  
          <p>Duis a turpis sed lacus dapibus elementum sed eu lectus.</p>
        </div>
      );
    }
}

class Contact extends React.Component{
  render() {
      return (
        <div>
          <h2>GOT QUESTIONS?</h2>
          <p>The easiest thing to do is post on
          our <a href="http://forum.kirupa.com">forums</a>.
          </p>
        </div>
      );
    }
}
 
class Stuff extends React.Component{
  render() {
      return (
        <div>
          <h2>STUFF</h2>
          <p>Mauris sem velit, vehicula eget sodales vitae,
          rhoncus eget sapien:</p>
          <ol>
            <li>Nulla pulvinar diam</li>
            <li>Facilisis bibendum</li>
            <li>Vestibulum vulputate</li>
            <li>Eget erat</li>
            <li>Id porttitor</li>
          </ol>
        </div>
      );
    }
}


export default App;