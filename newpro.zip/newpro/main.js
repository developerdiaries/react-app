import React from 'react';
import ReactDOM from 'react-dom';
import {  Router, Route, Link, browserHistory, IndexRoute  } from 'react-router'
import App from './App.jsx';
import Home from './App.jsx';
import Stuff from './App.jsx';
import Contact from './App.jsx';

/*
setTimeout(() => {
	ReactDOM.unmountComponentAtNode(document.getElementById('1'));
},1000);*/
ReactDOM.render(
	<Router  history = {browserHistory}>
		<Route path="/" component={App}>
			<IndexRoute component={Home}/>
			<Route path="stuff" component={Stuff} />
      		<Route path="contact" component={Contact} />
		</Route>
  	</Router>, document.getElementById('app'));
